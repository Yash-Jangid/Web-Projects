<?php
$con = mysqli_connect("localhost", "root", "", "todolist") or die("Database connection Stopped");
?>